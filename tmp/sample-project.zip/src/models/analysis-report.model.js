const mongoose = require("mongoose");

const analysisIssueSchema = new mongoose.Schema(
  {
    category: String,
    severity: String,
    title: String,
    description: String,
    file: String,
    recommendation: String,
    ruleId: String
  },
  {
    _id: false
  }
);

const analysisReportSchema = new mongoose.Schema(
  {
    projectId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Project",
      required: true
    },
    score: Number,
    security: Number,
    performance: Number,
    scalability: Number,
    reliability: Number,
    issues: {
      type: [analysisIssueSchema],
      default: []
    },
    breakdown: {
      type: mongoose.Schema.Types.Mixed,
      default: {}
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("AnalysisReport", analysisReportSchema);

const mongoose = require("mongoose");

const projectSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true
    },
    sourceType: {
      type: String,
      enum: ["github", "zip"],
      required: true
    },
    sourceLocation: {
      type: String,
      required: true
    },
    architectureId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Architecture"
    },
    analysisReportId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "AnalysisReport"
    },
    metadata: {
      totalFiles: {
        type: Number,
        default: 0
      },
      totalDirectories: {
        type: Number,
        default: 0
      }
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("Project", projectSchema);

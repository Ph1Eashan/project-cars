const mongoose = require("mongoose");

const architectureSchema = new mongoose.Schema(
  {
    projectId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Project",
      required: true
    },
    services: {
      type: [mongoose.Schema.Types.Mixed],
      default: []
    },
    apis: {
      type: [mongoose.Schema.Types.Mixed],
      default: []
    },
    dependencies: {
      type: [mongoose.Schema.Types.Mixed],
      default: []
    },
    databaseInteractions: {
      type: [mongoose.Schema.Types.Mixed],
      default: []
    },
    fileTree: {
      type: [mongoose.Schema.Types.Mixed],
      default: []
    },
    summary: {
      type: mongoose.Schema.Types.Mixed,
      default: {}
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("Architecture", architectureSchema);

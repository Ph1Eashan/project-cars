const {
  clampScore,
  getSeverityWeight
} = require("./analysis-rules/helpers");
const securityRules = require("./analysis-rules/security.rules");
const performanceRules = require("./analysis-rules/performance.rules");
const scalabilityRules = require("./analysis-rules/scalability.rules");
const reliabilityRules = require("./analysis-rules/reliability.rules");

const CATEGORY_RULES = {
  security: securityRules,
  performance: performanceRules,
  scalability: scalabilityRules,
  reliability: reliabilityRules
};

function normalizeRuleResult(rule, category, result) {
  if (!result) {
    return {
      scoreImpact: 0,
      issues: [],
      triggered: false
    };
  }

  const issues = result.issues || (result.issue ? [result.issue] : []);
  const scoreImpact = result.scoreImpact || issues.reduce((total, issue) => total + getSeverityWeight(issue.severity), 0);

  return {
    ruleId: rule.id,
    category,
    title: rule.title,
    description: rule.description,
    severity: rule.severity,
    triggered: issues.length > 0,
    scoreImpact,
    issues
  };
}

function evaluateCategory(category, rules, scanResult) {
  const ruleResults = rules.map((rule) => normalizeRuleResult(rule, category, rule.evaluate(scanResult)));
  const issues = ruleResults.flatMap((result) => result.issues);
  const totalImpact = ruleResults.reduce((sum, result) => sum + result.scoreImpact, 0);
  const score = clampScore(100 - totalImpact);

  return {
    score,
    issues,
    ruleResults
  };
}

function generateReport(scanResult) {
  const security = evaluateCategory("security", CATEGORY_RULES.security, scanResult);
  const performance = evaluateCategory("performance", CATEGORY_RULES.performance, scanResult);
  const scalability = evaluateCategory("scalability", CATEGORY_RULES.scalability, scanResult);
  const reliability = evaluateCategory("reliability", CATEGORY_RULES.reliability, scanResult);

  const score = Math.round(
    (security.score + performance.score + scalability.score + reliability.score) / 4
  );

  return {
    score,
    security: security.score,
    performance: performance.score,
    scalability: scalability.score,
    reliability: reliability.score,
    issues: [
      ...security.issues,
      ...performance.issues,
      ...scalability.issues,
      ...reliability.issues
    ],
    breakdown: {
      security: security.ruleResults,
      performance: performance.ruleResults,
      scalability: scalability.ruleResults,
      reliability: reliability.ruleResults
    }
  };
}

module.exports = {
  generateReport
};
